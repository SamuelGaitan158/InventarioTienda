import java.util.ArrayList;
import java.util.Scanner;


class Producto {
    private String codigo;
    private String nombre;
    private String categoria;
    private double precio;
    private int stock;

    public Producto(String codigo, String nombre, String categoria, double precio, int stock) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.categoria = categoria;
        this.precio = precio;
        this.stock = stock;
    }

    
    public String getCodigo() { return codigo; }
    public void setCodigo(String codigo) { this.codigo = codigo; }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public String getCategoria() { return categoria; }
    public void setCategoria(String categoria) { this.categoria = categoria; }

    public double getPrecio() { return precio; }
    public void setPrecio(double precio) { this.precio = precio; }

    public int getStock() { return stock; }
    public void setStock(int stock) { this.stock = stock; }

    @Override
    public String toString() {
        return "Codigo: " + codigo + " | Nombre: " + nombre + " | Categoria: " + categoria + 
               " | Precio: $" + precio + " | Stock: " + stock;
    }
}

public class InventarioTienda {
    public static void main(String[] args) {
        ArrayList<Producto> listaProductos = new ArrayList<>();
        Scanner scanner = new Scanner(System.in);

       
        listaProductos.add(new Producto("T01", "Laptop HP", "Tecnologia", 850.0, 5));
        listaProductos.add(new Producto("P01", "Cuaderno 100 hojas", "Papeleria", 2.5, 45));
        listaProductos.add(new Producto("M01", "Escritorio de madera", "Muebles", 150.0, 8));
        listaProductos.add(new Producto("E01", "Licuadora Oster", "Electrodomesticos", 75.0, 12));
        listaProductos.add(new Producto("T02", "Mouse Inalambrico", "Tecnologia", 25.0, 30));
        listaProductos.add(new Producto("M02", "Silla Ergonomica", "Muebles", 120.0, 4));

        int opcion;
        do {
           
            System.out.println("   SISTEMA DE GESTION DE INVENTARIO - TALLER");
            System.out.println("1. Ejecutar analisis del inventario (Punto 1 y 2)");
            System.out.println("2. Buscar producto por codigo");
            System.out.println("3. Actualizar precio");
            System.out.println("4. Actualizar stock");
            System.out.println("5. Eliminar producto");
            System.out.println("6. Mostrar inventario completo");
            System.out.println("7. Mostrar productos por categoria");
            System.out.println("8. Salir");
            System.out.print("Seleccione una opcion: ");
            
            while (!scanner.hasNextInt()) {
                System.out.println("Por favor, ingrese un numero valido.");
                scanner.next();
            }
            opcion = scanner.nextInt();
            scanner.nextLine(); 

            switch (opcion) {
                case 1:
                    ejecutarAnalisis(listaProductos);
                    break;
                case 2:
                    buscarPorCodigo(listaProductos, scanner);
                    break;
                case 3:
                    actualizarPrecio(listaProductos, scanner);
                    break;
                case 4:
                    actualizarStock(listaProductos, scanner);
                    break;
                case 5:
                    eliminarProducto(listaProductos, scanner);
                    break;
                case 6:
                    mostrarInventario(listaProductos);
                    break;
                case 7:
                    mostrarPorCategoria(listaProductos, scanner);
                    break;
                case 8:
                    System.out.println("¡Gracias por utilizar el sistema!");
                    break;
                default:
                    System.out.println("Opcion no valida. Intente nuevamente.");
            }
        } while (opcion != 8);

        scanner.close();
    }

  
    // SOLUCION PUNTO 1 y PUNTO 2

    public static void ejecutarAnalisis(ArrayList<Producto> lista) {
        if (lista.isEmpty()) {
            System.out.println("El inventario esta vacio.");
            return;
        }

        System.out.println("\n--- REPORTE PUNTO 1: ANALISIS GENERAL ---");
        int totalProductos = lista.size();
        double sumaPrecios = 0;
        Producto masCostoso = lista.get(0);
        Producto menorPrecio = lista.get(0);
        int stockMenorA10 = 0;

        for (Producto p : lista) {
            sumaPrecios += p.getPrecio();

            if (p.getPrecio() > masCostoso.getPrecio()) {
                masCostoso = p;
            }
            if (p.getPrecio() < menorPrecio.getPrecio()) {
                menorPrecio = p;
            }
            if (p.getStock() < 10) {
                stockMenorA10++;
            }
        }

        double promedioPrecios = sumaPrecios / totalProductos;

        System.out.println("* Cantidad total de productos registrados: " + totalProductos);
        System.out.println("* Valor promedio de los precios: $" + promedioPrecios);
        System.out.println("* Producto mas costoso: " + masCostoso.getNombre() + " ($" + masCostoso.getPrecio() + ")");
        System.out.println("* Producto con menor precio: " + menorPrecio.getNombre() + " ($" + menorPrecio.getPrecio() + ")");
        System.out.println("* Cantidad de productos con stock menor a 10 unidades: " + stockMenorA10);

        System.out.println("\n--- REPORTE PUNTO 2: LISTAS FILTRADAS Y VALOR DE INVENTARIO ---");
        ArrayList<Producto> productosTecnologia = new ArrayList<>();
        ArrayList<Producto> productosEconomicos = new ArrayList<>();

        
        for (Producto p : lista) {
            if (p.getCategoria().equalsIgnoreCase("Tecnologia")) {
                productosTecnologia.add(p);
            }
            if (p.getPrecio() < 200.0) {
                productosEconomicos.add(p);
            }
        }

        
        System.out.println("\n[Lista: productosTecnologia]");
        double valorInventarioTecnologia = 0;
        for (Producto p : productosTecnologia) {
            System.out.println("  - " + p);
            valorInventarioTecnologia += (p.getPrecio() * p.getStock());
        }
        System.out.println("-> Valor total del inventario (Tecnologia): $" + valorInventarioTecnologia);

        // Mostrar y calcular inventario de productosEconomicos
        System.out.println("\n[Lista: productosEconomicos (Precio < $200)]");
        double valorInventarioEconomicos = 0;
        for (Producto p : productosEconomicos) {
            System.out.println("  - " + p);
            valorInventarioEconomicos += (p.getPrecio() * p.getStock());
        }
        System.out.println("-> Valor total del inventario (Economicos): $" + valorInventarioEconomicos);
    }

    // SOLUCION PUNTO 3 (Opciones del Menu)
   

    // 1. Buscar producto por codigo
    public static void buscarPorCodigo(ArrayList<Producto> lista, Scanner scanner) {
        System.out.print("Ingrese el codigo del producto a buscar: ");
        String codigo = scanner.nextLine();
        boolean encontrado = false;

        for (Producto p : lista) {
            if (p.getCodigo().equalsIgnoreCase(codigo)) {
                System.out.println("\n¡Producto encontrado!");
                System.out.println(p);
                encontrado = true;
                break;
            }
        }
        if (!encontrado) {
            System.out.println("No se encontro ningun producto con el codigo: " + codigo);
        }
    }

    // 2. Actualizar precio
    public static void actualizarPrecio(ArrayList<Producto> lista, Scanner scanner) {
        System.out.print("Ingrese el codigo del producto cuyo precio desea actualizar: ");
        String codigo = scanner.nextLine();
        boolean encontrado = false;

        for (Producto p : lista) {
            if (p.getCodigo().equalsIgnoreCase(codigo)) {
                System.out.println("Producto actual: " + p);
                System.out.print("Ingrese el nuevo precio: ");
                while (!scanner.hasNextDouble()) {
                    System.out.println("Por favor, ingrese un valor numerico valido.");
                    scanner.next();
                }
                double nuevoPrecio = scanner.nextDouble();
                scanner.nextLine(); // Limpiar buffer
                
                p.setPrecio(nuevoPrecio);
                System.out.println("¡Precio actualizado con exito!");
                System.out.println(p);
                encontrado = true;
                break;
            }
        }
        if (!encontrado) {
            System.out.println("No se encontro ningun producto con el codigo: " + codigo);
        }
    }

    // 3. Actualizar stock
    public static void actualizarStock(ArrayList<Producto> lista, Scanner scanner) {
        System.out.print("Ingrese el codigo del producto cuyo stock desea actualizar: ");
        String codigo = scanner.nextLine();
        boolean encontrado = false;

        for (Producto p : lista) {
            if (p.getCodigo().equalsIgnoreCase(codigo)) {
                System.out.println("Producto actual: " + p);
                System.out.print("Ingrese el nuevo stock: ");
                while (!scanner.hasNextInt()) {
                    System.out.println("Por favor, ingrese un numero entero valido.");
                    scanner.next();
                }
                int nuevoStock = scanner.nextInt();
                scanner.nextLine(); // Limpiar buffer
                
                p.setStock(nuevoStock);
                System.out.println("¡Stock actualizado con exito!");
                System.out.println(p);
                encontrado = true;
                break;
            }
        }
        if (!encontrado) {
            System.out.println("No se encontro ningun producto con el codigo: " + codigo);
        }
    }

    // 4. Eliminar producto
    public static void eliminarProducto(ArrayList<Producto> lista, Scanner scanner) {
        System.out.print("Ingrese el codigo del producto que desea eliminar: ");
        String codigo = scanner.nextLine();
        boolean eliminado = false;

        for (int i = 0; i < lista.size(); i++) {
            if (lista.get(i).getCodigo().equalsIgnoreCase(codigo)) {
                System.out.println("Eliminando: " + lista.get(i).getNombre());
                lista.remove(i);
                eliminado = true;
                System.out.println("¡Producto eliminado con exito!");
                break;
            }
        }
        if (!eliminado) {
            System.out.println("No se encontro ningun producto con el codigo: " + codigo);
        }
    }

    // 5. Mostrar inventario completo
    public static void mostrarInventario(ArrayList<Producto> lista) {
        if (lista.isEmpty()) {
            System.out.println("El inventario esta vacio.");
            return;
        }
        System.out.println("\n--- INVENTARIO GENERAL DE LA TIENDA ---");
        for (Producto p : lista) {
            System.out.println(p);
        }
    }

    // 6. Mostrar productos por categoria
    public static void mostrarPorCategoria(ArrayList<Producto> lista, Scanner scanner) {
        if (lista.isEmpty()) {
            System.out.println("El inventario esta vacio.");
            return;
        }
        System.out.print("Ingrese la categoria a buscar (Tecnologia, Papeleria, Muebles, Electrodomesticos): ");
        String categoria = scanner.nextLine();
        boolean encontrado = false;

        System.out.println("\n--- PRODUCTOS EN LA CATEGORIA: " + categoria.toUpperCase() + " ---");
        for (Producto p : lista) {
            if (p.getCategoria().equalsIgnoreCase(categoria)) {
                System.out.println(p);
                encontrado = true;
            }
        }
        if (!encontrado) {
            System.out.println("No se encontraron productos registrados en esa categoria.");
        }
    }
}